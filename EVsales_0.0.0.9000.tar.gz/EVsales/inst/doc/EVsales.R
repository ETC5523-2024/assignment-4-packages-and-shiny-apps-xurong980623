## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE
)

## ----setup--------------------------------------------------------------------
library(EVsales)
library(dplyr)
library(ggplot2)
library(plotly)
library(DT)

## -----------------------------------------------------------------------------
# Load the EV sales data
data(ev_data)

# View the first few rows of the dataset
head(ev_data)

## -----------------------------------------------------------------------------
# Plot EV sales over time for all regions and powertrain types
plot_ev_sales_over_time(ev_data)

## -----------------------------------------------------------------------------
# Plot EV sales over time for Europe and Battery Electric Vehicles (BEV)
plot_ev_sales_over_time(ev_data, region = "Europe", powertrain = "BEV")

## -----------------------------------------------------------------------------
# Plot the worldwide distribution of powertrain types
plot_powertrain_distribution(ev_data)

## -----------------------------------------------------------------------------
# View the EV sales data in a table
view_ev_sales_data(ev_data)

